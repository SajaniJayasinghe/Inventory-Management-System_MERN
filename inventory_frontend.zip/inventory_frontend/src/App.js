import React,{Component} from "react";
import { BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import EditProduct from "./components/EditProduct";
import  './App.css';
import ProductDetails from "./components/ProductDetails";
import Navbar from './components/Navbar/Navbar';
import InventoryPage from './components/InventoryPage';


export default class App extends Component{
  render(){
    return(
      <>        
        <Router> 
       <div>
       <Navbar/> 

         <Route path="/inventory" exact component={InventoryPage}/>
         <Route path= "/edit/:productID" component ={EditProduct}/>
         <Route path= "/products/:productID" component ={ProductDetails}/>     
      </div>
      </Router>
      </>     
    )
  }
}