import React, { Component } from 'react'
import CreateProducts from "./CreateProducts";
import Home from "./Home";

export default class InventoryPage extends Component {
    render() {
        return (
            <div>
         

<br/><br/>
  
              <div>
                   <CreateProducts/>
              </div>
        
                 <div >   
                 <Home/>
</div> 
</div>

       
        )
    }
}
