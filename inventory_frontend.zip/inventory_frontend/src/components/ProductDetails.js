import React,{Component} from 'react';
import axios from 'axios';
import BookmarksIcon from '@material-ui/icons/Bookmarks';
import Button from '@material-ui/core/Button';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';


export default class ProductDetails extends Component{
    constructor(props){
       super(props);

       this.state = {
          products:{}
       };
    }
    
    componentDidMount(){
      const productID = this.props.match.params.productID;
      axios.get(`/products/${productID}`).then((res)=>{
         if(res.data.success){
           this.setState({
            products:res.data.products
         });        
         console.log(this.state.products);
        }
      });
   }

   render(){
      const{
         productName, quantity,originalTitle,productPrice, marketPrice, brandName,warrantYear,version,
         description,coverImage,availability,} = this.state.products;

  return(
   
   
    
          <div className="row"className="container"  align="center" >            
           <div className="container" >     
          
             <div className="card-image waves-effect waves-block waves-light">
             <img className="activator" style={{ width: '20%', height: '20%' }} src={coverImage} />
             </div>     

               <h6>Product Name  :&nbsp;&nbsp;&nbsp;{productName}</h6>
               <h6> &nbsp;&nbsp; &nbsp;&nbsp; Product Price&nbsp;&nbsp; : RS.{productPrice}</h6>
               </div>
                      
                <br/>
               <Button variant="contained" color="secondary" startIcon={<BookmarksIcon/>} size="small">
                 WishList
               </Button>
               
               &nbsp;&nbsp;&nbsp;

               <Button variant="contained" color="primary" startIcon={<AddShoppingCartIcon/>} size="small">
                ADD TO CART
               </Button>

               &nbsp;&nbsp;&nbsp;

               <Button variant="contained"  startIcon={<AddShoppingCartIcon/>} size="small">
               BUY IT NOW
               </Button>
                        
               <br/><br/>
                  <div className="p-2"align="center" >
                    <h4 ><b><u>Product Information</u></b></h4><br/>
                      <table style={{ fontSize: 18 }}>
                      <tbody>
                        <tr>
                          <td><b>Product Name</b></td>
                          <td style={{ paddingLeft: 18 }}>: {productName}</td>
                        </tr>

                        <tr>
                          <td><b>Availability</b></td>
                          <td style={{ paddingLeft: 18 }}>: {availability}</td>
                        </tr>

                        <tr>
                          <td><b>Quantity</b></td>
                          <td style={{ paddingLeft: 18 }}>: {quantity}</td>
                        </tr>

                      
                        <tr>
                          <td><b>Original Title</b></td>
                          <td style={{ paddingLeft: 18 }}>: {originalTitle}</td>
                        </tr>

                        <tr>
                          <td><b>Product Price</b></td>
                          <td style={{ paddingLeft: 18 }}>: {productPrice}</td>
                        </tr>
       
                        <tr>
                          <td><b>Market Price</b></td>
                          <td style={{ paddingLeft: 18 }}>: {marketPrice}</td>
                        </tr>
                        <tr>
                          <td><b>Brand Name</b></td>
                          <td style={{ paddingLeft: 18 }}>: {brandName}</td>
                        </tr>
                        <tr>
                          <td><b>Warrant Year</b></td>
                          <td style={{ paddingLeft: 18 }}>: {warrantYear}</td>
                        </tr>
                        <tr>
                          <td><b>Version</b></td>
                          <td style={{ paddingLeft: 18 }}>: {version}</td>
                        </tr>
                        
                        <tr>
                          <td><b>Description</b></td>
                          <td style={{ paddingLeft: 18 }}>: {description}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>                
             </div> 
     )
    }
}