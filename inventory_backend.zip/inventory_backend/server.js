const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

//import routes
const productRoutes = require('./routes/products');
const productPDFRoutes = require ('./routes/PDF-Generator/products-report')

//app middleware
app.use(bodyParser.json());
app.use(cors());
app.use(productPDFRoutes)


app.use( bodyParser.json({limit: '50mb'}) );
app.use(bodyParser.urlencoded({
  limit: '50mb',
  extended: true,
  parameterLimit:50000
}));

//routes middleware
app.use(productRoutes);
const PORT = 8000;
const DB_URL = 'mongodb+srv://Sajani:*sajani0729@cluster0.u77r7.mongodb.net/invenoryDB?retryWrites=true&w=majority';

mongoose.connect(DB_URL,{
   useNewUrlParser : true,
   useUnifiedTopology : true
})


.then(()=>{
    console.log('MongoDB Successful !!');

})
.catch((err)=> console.log('DB Connection error',err));

app.listen(PORT, ()=>{
    console.log(`App is running in ${PORT}`);

});